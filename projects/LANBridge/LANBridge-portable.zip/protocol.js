/**
 * LANBridge 프로토콜
 * 세션, 피어, 메시지 ID 생성 및 메시지 구조 관리
 */
class Protocol {
  /**
   * 세션 ID 생성 (형식: S_[타임스탬프]_[랜덤])
   * @returns {string} 고유한 세션 ID
   */
  generateSessionId() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `S_${timestamp}_${random}`;
  }

  /**
   * 피어 ID 생성 (형식: P_[랜덤])
   * @returns {string} 고유한 피어 ID
   */
  generatePeerId() {
    const random = Math.random().toString(36).substring(2, 14).toUpperCase();
    return `P_${random}`;
  }

  /**
   * 메시지 ID 생성 (형식: M_[타임스탬프]_[랜덤])
   * @returns {string} 고유한 메시지 ID
   */
  generateMessageId() {
    return `M_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  }

  /**
   * 메시지 객체 생성
   * @param {string} type - 메시지 타입 (chat, file, etc.)
   * @param {*} payload - 메시지 내용
   * @param {object} options - 추가 옵션
   * @returns {object} 구조화된 메시지 객체
   */
  createMessage(type, payload, options = {}) {
    return {
      id: this.generateMessageId(),
      type,
      payload,
      timestamp: Date.now(),
      ...options
    };
  }
}
