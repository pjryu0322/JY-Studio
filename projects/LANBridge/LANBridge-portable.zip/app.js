/**
 * LANBridge 메인 앱
 * 역할: 공유자 / 참여자 / 관리자
 */

class LANBridge {
  constructor() {
    this.protocol = new Protocol();
    this.connection = null;
    this.role = null; // 'host' | 'join' | 'admin'
    this.sessionId = this.protocol.generateSessionId();
    this.myPeerId = this.protocol.generatePeerId();
    this.serverAddr = null;
    this.roomId = null;
    this.hostName = null;
    this.hostRooms = new Map();
    this.activeRoomId = null;
    this._beforeUnloadHandler = null;
  }

  /**
   * 서버 연결 테스트
   * @param {string} serverAddr - 서버 주소 (host:port)
   * @throws {Error} 서버 연결 실패
   */
  async _testConnection(serverAddr) {
    try {
      const response = await fetch(`http://${serverAddr}/health`, { timeout: 5000 });
      if (!response.ok) throw new Error(`신호 서버 응답 오류: ${response.status}`);
      return true;
    } catch (error) {
      throw new Error(`신호 서버 연결 실패: ${error.message}`);
    }
  }

  // ============================================
  // 공유자 모드
  // ============================================
  /**
   * 공유자로 시작 (방 생성 및 Offer 준비)
   * @param {string} hostName - 공유자 이름
   * @param {string} serverAddr - 신호 서버 주소
   * @param {string} roomTitle - 방 제목
   * @throws {Error} 방 생성 실패
   */
  async startAsHost(hostName, serverAddr, roomTitle) {
    console.log('[App] 공유자 시작:', hostName, 'at', serverAddr);
    this.role = 'host';
    this.hostName = hostName;
    this.roomTitle = roomTitle;
    this.serverAddr = serverAddr;

    try {
      // 서버 연결 테스트
      await this._testConnection(serverAddr);

      // 신호 서버에 방 생성
      const createRes = await fetch(`http://${serverAddr}/api/room/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostId: this.myPeerId,
          hostName: hostName,
          roomTitle: roomTitle
        })
      });

      if (!createRes.ok) throw new Error(`방 생성 API 오류: ${createRes.status}`);
      const createData = await createRes.json();
      if (!createData.success) {
        throw new Error(createData.error || '방 생성 실패');
      }

      const roomId = createData.roomId;
      console.log('[App] 방 생성됨:', roomId);

      // WebRTC 연결 시작
      const connection = new HostConnection(this, roomId);
      const offer = await connection.start();

      // Offer 서버에 저장
      const offerRes = await fetch(`http://${serverAddr}/api/room/${roomId}/offer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(offer)
      });

      if (!offerRes.ok) throw new Error(`Offer 저장 API 오류: ${offerRes.status}`);
      const offerResult = await offerRes.json();
      if (!offerResult.success) {
        throw new Error(offerResult.error || 'Offer 저장 실패');
      }

      console.log('[App] ✅ 방 개설 완료');

      const roomInfo = {
        roomId,
        roomTitle,
        hostName,
        serverAddr,
        connection,
        heartbeatTimer: null,
        closed: false
      };

      this.hostRooms.set(roomId, roomInfo);
      this.activeRoomId = roomId;
      this.roomId = roomId;
      this.connection = connection;

      this._startHostHeartbeat(roomId);

      if (typeof window !== 'undefined') {
        this._beforeUnloadHandler = () => {
          this._closeAllRooms(true);
        };
        window.addEventListener('beforeunload', this._beforeUnloadHandler);
      }

      // 연결 종료 시 방 삭제 처리
      // 참여자의 Answer를 기다리자
      this.waitForAnswer(roomId, connection);

      return { roomId };

    } catch (error) {
      console.error('[App] 공유자 시작 실패:', error.message);
      throw error;
    }
  }

  /**
   * 참여자 Answer 대기 (폴링)
   * @private
   */
  async waitForAnswer(roomId, connection) {
    console.log('[App] Answer 대기 중... (최대 5분)');
    
    for (let i = 0; i < 600; i++) { // 600 * 500ms = 5분
      await new Promise(r => setTimeout(r, 500));

      try {
        const answerRes = await fetch(`http://${this.serverAddr}/api/room/${roomId}/answer`);
        if (!answerRes.ok) continue;
        
        const answerData = await answerRes.json();

        if (answerData.answer) {
          console.log('[App] Answer 수신!');
          await connection.applyAnswer(answerData.answer);
          console.log('[App] ✅ 연결 시도 중... (최대 10초 대기)');
          
          // P2P 연결 확인 (최대 10초)
          for (let j = 0; j < 20; j++) {
            await new Promise(r => setTimeout(r, 500));
            if (connection.pc?.connectionState === 'connected') {
              console.log('[App] ✅ P2P 연결 성공!');
              return;
            }
          }
          
          console.warn('[App] ⚠️  P2P 연결 실패 - 참여자가 방에 입장할 수 없음');
          return;
        }
      } catch (error) {
        // 무시
      }
    }

    console.warn('[App] Answer 타임아웃 (5분)');
  }

  // ============================================
  // 참여자 모드
  // ============================================
  /**
   * 활성 방 목록 검색
   * @param {string} serverAddr - 신호 서버 주소
   * @returns {Promise<array>} 방 목록
   * @throws {Error} 서버 연결 실패
   */
  async searchRooms(serverAddr) {
    console.log('[App] 방 검색:', serverAddr);
    this.role = 'join';
    this.serverAddr = serverAddr;

    try {
      await this._testConnection(serverAddr);

      const res = await fetch(`http://${serverAddr}/api/rooms`);
      if (!res.ok) throw new Error(`API 오류: ${res.status}`);
      
      const data = await res.json();
      
      if (!data.success) {
        throw new Error(data.error || '신호 서버에 연결할 수 없습니다');
      }

      return data.rooms || [];
    } catch (error) {
      throw new Error('신호 서버 연결 실패: ' + error.message);
    }
  }

  /**
   * 방 입장 (Answer 생성 및 전송)
   * @param {string} roomId - 방 ID
   * @param {string} serverAddr - 신호 서버 주소
   * @param {string} participantName - 참여자 이름
   * @throws {Error} 방 입장 실패
   */
  async joinRoom(roomId, serverAddr, participantName) {
    console.log('[App] 방 입장:', roomId, participantName);
    this.role = 'join';
    this.serverAddr = serverAddr;
    this.roomId = roomId;

    // 참여자 등록
    try {
      await fetch(`http://${serverAddr}/api/room/${roomId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ participantName })
      });
    } catch (error) {
      console.warn('[App] 참여자 등록 실패:', error.message);
    }

    // WebRTC 연결 시작
    this.connection = new JoinConnection(this, roomId);
    
    try {
      // Offer 조회
      const offerRes = await fetch(`http://${serverAddr}/api/room/${roomId}/offer`);
      if (!offerRes.ok) throw new Error(`Offer 조회 API 오류: ${offerRes.status}`);
      
      const offerData = await offerRes.json();

      if (!offerData.success || !offerData.offer) {
        throw new Error(offerData.error || '아직 공유자의 Offer가 준비되지 않았습니다');
      }

      // Answer 생성
      const answer = await this.connection.start(offerData.offer);

      // Answer 전송
      const answerRes = await fetch(`http://${serverAddr}/api/room/${roomId}/answer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participantId: this.myPeerId,
          participantName,
          answer
        })
      });

      if (!answerRes.ok) throw new Error(`Answer 전송 API 오류: ${answerRes.status}`);
      const answerResult = await answerRes.json();
      if (!answerResult.success) {
        throw new Error(answerResult.error || 'Answer 전송 실패');
      }

      console.log('[App] ✅ 방에 입장했습니다');
    } catch (error) {
      console.error('[App] 방 입장 실패:', error.message);
      throw error;
    }
  }

  _startHostHeartbeat(roomId) {
    const roomInfo = this.hostRooms.get(roomId);
    if (!roomInfo || roomInfo.heartbeatTimer) return;

    roomInfo.heartbeatTimer = setInterval(() => {
      fetch(`http://${roomInfo.serverAddr}/api/room/${roomId}/ping`, {
        method: 'POST',
        keepalive: true
      }).catch(() => {});
    }, 15000);
  }

  _stopHostHeartbeat(roomId) {
    const roomInfo = this.hostRooms.get(roomId);
    if (roomInfo?.heartbeatTimer) {
      clearInterval(roomInfo.heartbeatTimer);
      roomInfo.heartbeatTimer = null;
    }
  }

  async _closeRoom(roomId, isKeepalive) {
    const roomInfo = this.hostRooms.get(roomId);
    if (!roomInfo || roomInfo.closed) return;
    roomInfo.closed = true;

    try {
      const delRes = await fetch(`http://${roomInfo.serverAddr}/api/room/${roomId}`, {
        method: 'DELETE',
        keepalive: Boolean(isKeepalive)
      });
      if (delRes.ok) {
        console.log('[App] 방이 폐쇄되었습니다');
      }
    } catch (error) {
      console.error('[App] 방 삭제 실패:', error.message);
    }
  }

  _closeAllRooms(isKeepalive) {
    for (const roomId of this.hostRooms.keys()) {
      this._closeRoom(roomId, isKeepalive);
      this._stopHostHeartbeat(roomId);
    }

    if (this._beforeUnloadHandler && typeof window !== 'undefined') {
      window.removeEventListener('beforeunload', this._beforeUnloadHandler);
      this._beforeUnloadHandler = null;
    }
  }

  setActiveRoom(roomId) {
    if (this.hostRooms.has(roomId)) {
      this.activeRoomId = roomId;
      this.roomId = roomId;
      this.connection = this.hostRooms.get(roomId)?.connection || null;
    }
  }

  getActiveConnection() {
    if (this.role === 'host' && this.activeRoomId) {
      return this.hostRooms.get(this.activeRoomId)?.connection || null;
    }
    return this.connection;
  }

  getRoomConnection(roomId) {
    return this.hostRooms.get(roomId)?.connection || null;
  }

  async closeHostRoom(roomId, isKeepalive) {
    const roomInfo = this.hostRooms.get(roomId);
    if (!roomInfo) return false;

    this._stopHostHeartbeat(roomId);
    await this._closeRoom(roomId, isKeepalive);

    try {
      roomInfo.connection?.close?.();
    } catch (error) {
      console.warn('[App] 방 연결 종료 실패:', error.message);
    }

    this.hostRooms.delete(roomId);
    if (this.activeRoomId === roomId) {
      this.activeRoomId = null;
      this.connection = null;
      this.roomId = null;
    }

    return true;
  }

  // ============================================
  // 콜백 (WebRTC 이벤트)
  // ============================================
  onConnectionOpen(roomId) {
    console.log('[App] 💬 DataChannel 열림!', roomId || '');
    const statusEl = document.getElementById('status');
    if (statusEl) statusEl.style.setProperty('color', 'green');
  }

  onConnectionClose(roomId) {
    console.log('[App] 연결 종료', roomId || '');
    const statusEl = document.getElementById('status');
    if (statusEl) statusEl.style.setProperty('color', 'red');

    if (this.role === 'host' && roomId) {
      if (!this.hostRooms.has(roomId)) {
        return;
      }
      this._stopHostHeartbeat(roomId);
      this._closeRoom(roomId, false);
      this.hostRooms.delete(roomId);
      if (this.activeRoomId === roomId) {
        this.activeRoomId = null;
        this.connection = null;
        this.roomId = null;
      }
    }
  }

  onMessage(message) {
    console.log('[App] 메시지 수신:', message);
  }
}

