#!/usr/bin/env node

/**
 * LANBridge Signal Server
 * 역할: 방 관리, SDP 중계, 참여자 발견
 * 
 * 엔드포인트:
 * - GET  /health              : 서버 상태 확인
 * - GET  /api/rooms           : 활성 방 목록 조회
 * - POST /api/room/create     : 방 생성
 * - POST /api/room/:id/offer  : Offer 저장
 * - GET  /api/room/:id/offer  : Offer 조회
 * - POST /api/room/:id/answer : Answer 저장
 * - GET  /api/room/:id/answer : Answer 조회
 * - POST /api/room/:id/join   : 참여자 등록
 * - DELETE /api/room/:id      : 방 폐쇄
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOM_TTL_MS = 60000; // 60 seconds
const CLEANUP_INTERVAL_MS = 30000;

// 활성 방 저장소 (메모리)
const rooms = new Map();

function generateRoomId() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return crypto.randomBytes(16).toString('hex');
}

/**
 * 응답 전송 헬퍼 함수
 * @param {http.ServerResponse} res - 응답 객체
 * @param {number} statusCode - HTTP 상태 코드
 * @param {object} data - 응답 JSON 데이터
 */
function sendResponse(res, statusCode, data) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

/**
 * 요청 본문 파싱
 * @param {http.IncomingMessage} req - 요청 객체
 * @returns {Promise<string>} 본문 데이터
 */
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

// HTTP 서버
const server = http.createServer(async (req, res) => {
  // CORS 헤더
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  console.log(`[Signal] ${req.method} ${pathname}`);

  try {
    // ============================================
    // GET /health - 헬스 체크
    // ============================================
    if (pathname === '/health' && req.method === 'GET') {
      sendResponse(res, 200, { 
        success: true, 
        message: 'Signal Server is running' 
      });
      return;
    }

    // ============================================
    // POST /api/room/create - 공유자: 방 생성
    // ============================================
    if (pathname === '/api/room/create' && req.method === 'POST') {
      const body = await parseBody(req);
      const data = JSON.parse(body);

      if (!data.hostId || !data.hostName) {
        return sendResponse(res, 400, { 
          success: false, 
          error: '필수 필드: hostId, hostName' 
        });
      }

      const roomId = generateRoomId().substring(0, 8).toUpperCase();
      const roomTitle = (data.roomTitle || '').trim() || `${data.hostName}의 방`;
      
      rooms.set(roomId, {
        id: roomId,
        hostId: data.hostId,
        hostName: data.hostName,
        roomTitle: roomTitle,
        createdAt: Date.now(),
        lastSeen: Date.now(),
        offer: null,
        answer: null,
        participants: [data.hostName]
      });

      console.log(`[Signal] 방 생성: ${roomId}, 방장: ${data.hostName}, 제목: ${roomTitle}`);
      sendResponse(res, 201, { 
        success: true, 
        roomId,
        expiresIn: 3600000 
      });
      return;
    }

    // ============================================
    // GET /api/rooms - 참여자: 활성 방 목록 조회
    // ============================================
    if (pathname === '/api/rooms' && req.method === 'GET') {
      const now = Date.now();
      const roomList = Array.from(rooms.values())
        .filter(room => now - room.lastSeen <= ROOM_TTL_MS)
        .map(room => ({
        id: room.id,
        hostName: room.hostName,
        roomTitle: room.roomTitle,
        createdAt: room.createdAt,
        participants: room.participants.length,
        participantNames: room.participants
      }));

      console.log(`[Signal] 방 목록 조회: ${roomList.length}개`);
      sendResponse(res, 200, { 
        success: true, 
        rooms: roomList 
      });
      return;
    }

    // ============================================
    // POST /api/room/:roomId/offer - 공유자: Offer 설정
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/offer') && req.method === 'POST') {
      const roomId = pathname.split('/')[3];
      const body = await parseBody(req);
      const data = JSON.parse(body);
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      room.offer = data.offer || data;
      room.lastSeen = Date.now();
      console.log(`[Signal] Offer 저장: ${roomId}`);
      sendResponse(res, 200, { success: true });
      return;
    }

    // ============================================
    // GET /api/room/:roomId/offer - 참여자: Offer 조회
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/offer') && req.method === 'GET') {
      const roomId = pathname.split('/')[3];
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      if (!room.offer) {
        return sendResponse(res, 202, { 
          success: false, 
          error: '아직 Offer가 준비되지 않았습니다' 
        });
      }

      room.lastSeen = Date.now();
      console.log(`[Signal] Offer 조회: ${roomId}`);
      sendResponse(res, 200, { success: true, offer: room.offer });
      return;
    }

    // ============================================
    // POST /api/room/:roomId/join - 참여자 등록
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/join') && req.method === 'POST') {
      const roomId = pathname.split('/')[3];
      const body = await parseBody(req);
      const data = JSON.parse(body);
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      if (!data.participantName) {
        return sendResponse(res, 400, { 
          success: false, 
          error: '필수 필드: participantName' 
        });
      }

      if (!room.participants.includes(data.participantName)) {
        room.participants.push(data.participantName);
      }

      room.lastSeen = Date.now();
      
      console.log(`[Signal] 참여자 추가: ${roomId}, ${data.participantName}, 총 ${room.participants.length}명`);
      sendResponse(res, 200, { 
        success: true, 
        participantCount: room.participants.length 
      });
      return;
    }

    // ============================================
    // POST /api/room/:roomId/answer - 참여자: Answer 설정
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/answer') && req.method === 'POST') {
      const roomId = pathname.split('/')[3];
      const body = await parseBody(req);
      const data = JSON.parse(body);
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      room.answer = data.answer;
      room.lastSeen = Date.now();
      console.log(`[Signal] Answer 저장: ${roomId}, 참여자: ${data.participantName}`);
      sendResponse(res, 200, { success: true });
      return;
    }

    // ============================================
    // GET /api/room/:roomId/answer - 공유자: Answer 조회
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/answer') && req.method === 'GET') {
      const roomId = pathname.split('/')[3];
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      if (!room.answer) {
        return sendResponse(res, 202, { 
          success: false, 
          error: '아직 Answer가 준비되지 않았습니다' 
        });
      }

      room.lastSeen = Date.now();
      console.log(`[Signal] Answer 조회: ${roomId}`);
      sendResponse(res, 200, { success: true, answer: room.answer });
      return;
    }

    // ============================================
    // POST /api/room/:roomId/ping - 방 상태 유지
    // ============================================
    if (pathname.startsWith('/api/room/') && pathname.endsWith('/ping') && req.method === 'POST') {
      const roomId = pathname.split('/')[3];
      const room = rooms.get(roomId);

      if (!room) {
        return sendResponse(res, 404, {
          success: false,
          error: '방을 찾을 수 없습니다'
        });
      }

      room.lastSeen = Date.now();
      sendResponse(res, 200, { success: true });
      return;
    }

    // ============================================
    // DELETE /api/room/:roomId - 방장: 방 폐쇄
    // ============================================
    if (pathname.startsWith('/api/room/') && req.method === 'DELETE') {
      const parts = pathname.split('/');
      if (parts.length === 4 && parts[2] === 'room') {
        const roomId = parts[3];
        const room = rooms.get(roomId);
        
        if (!room) {
          return sendResponse(res, 404, { 
            success: false, 
            error: '방을 찾을 수 없습니다' 
          });
        }

        rooms.delete(roomId);
        console.log(`[Signal] 방 폐쇄: ${roomId}, 방장: ${room.hostName}`);
        sendResponse(res, 200, { 
          success: true, 
          message: '방이 폐쇄되었습니다' 
        });
        return;
      }
    }

    // ============================================
    // GET /api/room/:roomId - 방 정보 조회
    // ============================================
    if (pathname.startsWith('/api/room/') && req.method === 'GET') {
      const roomId = pathname.split('/')[3];
      const room = rooms.get(roomId);
      
      if (!room) {
        return sendResponse(res, 404, { 
          success: false, 
          error: '방을 찾을 수 없습니다' 
        });
      }

      sendResponse(res, 200, { 
        success: true, 
        room: {
          id: room.id,
          hostName: room.hostName,
          roomTitle: room.roomTitle,
          createdAt: room.createdAt,
          participants: room.participants
        }
      });
      return;
    }

    // ============================================
    // GET /, /index - 앱 페이지
    // ============================================
    if ((pathname === '/' || pathname === '/index' || pathname === '/index.html') && req.method === 'GET') {
      const indexPath = path.join(__dirname, 'index.html');
      fs.readFile(indexPath, 'utf8', (err, html) => {
        if (err) {
          return sendResponse(res, 500, { success: false, error: 'index.html 로드 실패' });
        }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(html);
      });
      return;
    }

    // ============================================
    // GET /status - 상태 페이지
    // ============================================
    if (pathname === '/status' && req.method === 'GET') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.writeHead(200);
      res.end(`
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LANBridge Signal Server</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 16px;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        h1 { color: #667eea; margin-bottom: 20px; }
        .status { 
            background: #dcfce7; 
            border-left: 4px solid #10b981;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 600;
            color: #059669;
        }
        .info { 
            background: #f0f4ff;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .info strong { color: #667eea; }
        .endpoints {
            background: #f9fafb;
            padding: 15px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 12px;
            line-height: 1.8;
        }
        code {
            background: white;
            padding: 2px 6px;
            border-radius: 3px;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎛️ LANBridge Signal Server</h1>
        <div class="status">✅ 서버 정상 실행 중</div>
        <div class="info">
            <strong>포트:</strong> ${PORT}<br>
            <strong>활성 방:</strong> ${rooms.size}개<br>
            <strong>시작 시간:</strong> ${new Date().toLocaleString('ko-KR')}
        </div>
        <h3 style="margin-bottom: 10px; color: #333;">API 엔드포인트</h3>
        <div class="endpoints">
            <div>GET  <code>/health</code> - 서버 상태 확인</div>
            <div>GET  <code>/api/rooms</code> - 활성 방 목록</div>
            <div>POST <code>/api/room/create</code> - 방 생성</div>
            <div>POST <code>/api/room/:id/offer</code> - Offer 제출</div>
            <div>GET  <code>/api/room/:id/offer</code> - Offer 조회</div>
            <div>POST <code>/api/room/:id/answer</code> - Answer 제출</div>
            <div>GET  <code>/api/room/:id/answer</code> - Answer 조회</div>
        </div>
    </div>
</body>
</html>
      `);
      return;
    }

    // ============================================
    // 정적 파일 제공 (JS, CSS 등)
    // ============================================
    const allowedExtensions = ['.js', '.css', '.html'];
    const ext = path.extname(pathname);

    if (allowedExtensions.includes(ext) && req.method === 'GET') {
      const safePath = pathname.replace(/^\/+/, '');
      const filePath = path.normalize(path.join(__dirname, safePath));

      if (!filePath.startsWith(__dirname)) {
        return sendResponse(res, 403, { success: false, error: 'Forbidden' });
      }

      fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
          return sendResponse(res, 404, { success: false, error: '파일을 찾을 수 없습니다' });
        }

        const contentTypes = {
          '.js': 'application/javascript; charset=utf-8',
          '.css': 'text/css; charset=utf-8',
          '.html': 'text/html; charset=utf-8'
        };

        res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'text/plain; charset=utf-8' });
        res.end(data);
      });
      return;
    }

    // 404
    sendResponse(res, 404, { 
      success: false, 
      error: '경로를 찾을 수 없습니다' 
    });

  } catch (error) {
    console.error('[Signal] 서버 오류:', error.message);
    sendResponse(res, 500, { 
      success: false, 
      error: '서버 내부 오류: ' + error.message 
    });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  const os = require('os');
  const interfaces = os.networkInterfaces();
  let localIP = 'localhost';
  
  // LAN IP 찾기
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        localIP = iface.address;
        break;
      }
    }
  }

  console.log(`
╔═══════════════════════════════════════════╗
║     LANBridge P2P Signal Server          ║
║     (Local WiFi Network Only)             ║
╠═══════════════════════════════════════════╣
║  📍 접속 주소:                             ║
║     http://localhost:${PORT}              ║
║     http://${localIP}:${PORT}              ║
║                                           ║
║  💡 같은 WiFi에 연결된 PC들만 접속 가능    ║
╚═══════════════════════════════════════════╝
  `);
});

// 서버 에러 처리
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`[Signal] ❌ 포트 ${PORT}이(가) 이미 사용 중입니다.`);
    console.error(`[Signal] 해결 방법:`);
    console.error(`  1. 다른 Signal Server 프로세스 종료:`);
    console.error(`     netstat -ano | findstr :${PORT}  (Windows)`);
    console.error(`     lsof -i :${PORT}               (Mac/Linux)`);
    console.error(`  2. 포트 변경: PORT=3001 node signal-server.js`);
  } else {
    console.error(`[Signal] ❌ 서버 오류:`, error.message);
  }
  process.exit(1);
});

// 정기적 방 정리 (하트비트 끊긴 방 삭제)
setInterval(() => {
  const now = Date.now();
  let deleted = 0;
  for (const [roomId, room] of rooms.entries()) {
    if (now - room.lastSeen > ROOM_TTL_MS) {
      rooms.delete(roomId);
      deleted++;
    }
  }
  if (deleted > 0) {
    console.log(`[Signal] ${deleted}개의 비활성 방 삭제됨`);
  }
}, CLEANUP_INTERVAL_MS);

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Signal] 서버 종료 중...');
  server.close(() => {
    console.log('[Signal] ✅ 서버 종료됨');
    process.exit(0);
  });
});
