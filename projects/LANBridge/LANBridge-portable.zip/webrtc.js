/**
 * WebRTC 모듈 - 공유자/참여자 역할 분리
 * HostConnection: Offer 생성자 (공유자)
 * JoinConnection: Answer 생성자 (참여자)
 */

const RTCConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
    { urls: 'stun:stun4.l.google.com:19302' }
  ],
  bundlePolicy: 'max-bundle',
  rtcpMuxPolicy: 'require',
  iceCandidatePoolSize: 10
};

/**
 * 기본 ICE 수집 대기 함수 (공통 로직)
 * @param {RTCPeerConnection} pc - 피어 연결 객체
 * @returns {Promise} ICE 수집 완료 시 resolve
 */
function waitForICE(pc) {
  return new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') {
      resolve();
      return;
    }

    const check = () => {
      if (pc.iceGatheringState === 'complete') {
        pc.removeEventListener('icegatheringstatechange', check);
        resolve();
      }
    };
    pc.addEventListener('icegatheringstatechange', check);

    // 타임아웃: 10초 후 무조건 진행
    setTimeout(() => {
      pc.removeEventListener('icegatheringstatechange', check);
      resolve();
    }, 10000);
  });
}

/**
 * 기본 DataChannel 이벤트 설정 (공통 로직)
 * @param {RTCDataChannel} dc - 데이터 채널
 * @param {object} app - LANBridge 앱 인스턴스
 * @param {string} role - 역할 구분 ('Host' 또는 'Join')
 */
function setupDataChannelEvents(dc, app, role, roomId) {
  dc.onopen = () => {
    console.log(`[${role} DC] ✅ OPEN!`);
    app.onConnectionOpen?.(roomId);
  };

  dc.onmessage = (e) => {
    try {
      app.onMessage?.(JSON.parse(e.data), roomId);
    } catch (error) {
      console.error(`[${role} DC] 메시지 파싱 오류:`, error);
    }
  };

  dc.onerror = (e) => {
    console.error(`[${role} DC] 에러:`, e);
  };

  dc.onclose = () => {
    console.log(`[${role} DC] 연결 종료`);
    app.onConnectionClose?.(roomId);
  };
}

// ============================================
// 공유자 (Host/Offerer)
// ============================================
class HostConnection {
  /**
   * 공유자 연결 생성
   * @param {LANBridge} app - LANBridge 앱 인스턴스
   */
  constructor(app, roomId) {
    console.log('[Host] 생성');
    this.app = app;
    this.roomId = roomId;
    this.pc = null;
    this.dataChannel = null;
  }

  /**
   * 공유자 연결 시작 (Offer 생성)
   * @returns {Promise} Offer 객체 반환
   */
  async start() {
    console.log('[Host] 연결 시작');
    
    this.pc = new RTCPeerConnection(RTCConfig);
    this.setupPCEvents();

    // DataChannel 생성 (createOffer 전에!)
    this.dataChannel = this.pc.createDataChannel('lanbridge', { ordered: true });
    setupDataChannelEvents(this.dataChannel, this.app, 'Host', this.roomId);
    console.log('[Host] DataChannel 생성됨');

    // Offer 생성
    const offer = await this.pc.createOffer();
    await this.pc.setLocalDescription(offer);
    console.log('[Host] Offer 생성됨');

    await waitForICE(this.pc);

    return { type: 'offer', sdp: this.pc.localDescription.sdp };
  }

  /**
   * 참여자의 Answer 적용
   * @param {object} answerData - Answer SDP 정보
   */
  async applyAnswer(answerData) {
    console.log('[Host] Answer 적용');
    await this.pc.setRemoteDescription(new RTCSessionDescription(answerData));
    console.log('[Host] ✅ 연결 성공!');
  }

  /**
   * P2P 연결 상태 변화 감시
   */
  setupPCEvents() {
    this.pc.oniceconnectionstatechange = () => {
      console.log('[Host ICE]:', this.pc.iceConnectionState);
      if (this.pc.iceConnectionState === 'disconnected' || 
          this.pc.iceConnectionState === 'failed' || 
          this.pc.iceConnectionState === 'closed') {
        console.log('[Host] 연결 종료됨');
        this.app.onConnectionClose?.(this.roomId);
      }
    };
  }

  /**
   * 메시지 전송
   * @param {object} message - 전송할 메시지
   * @returns {boolean} 전송 성공 여부
   */
  send(message) {
    if (this.dataChannel?.readyState === 'open') {
      try {
        this.dataChannel.send(JSON.stringify(message));
        return true;
      } catch (error) {
        console.error('[Host] 메시지 전송 오류:', error);
        return false;
      }
    }
    return false;
  }

  /**
   * 연결 종료
   */
  close() {
    console.log('[Host] 연결 종료');
    this.dataChannel?.close();
    this.pc?.close();
  }
}

// ============================================
// 참여자 (Join/Answerer)
// ============================================
class JoinConnection {
  /**
   * 참여자 연결 생성
   * @param {LANBridge} app - LANBridge 앱 인스턴스
   */
  constructor(app, roomId) {
    console.log('[Join] 생성');
    this.app = app;
    this.roomId = roomId;
    this.pc = null;
    this.dataChannel = null;
  }

  /**
   * 참여자 연결 시작 (Answer 생성)
   * @param {object} offerData - 공유자의 Offer SDP 정보
   * @returns {Promise} Answer 객체 반환
   */
  async start(offerData) {
    console.log('[Join] 연결 시작');
    
    this.pc = new RTCPeerConnection(RTCConfig);
    this.setupPCEvents();

    // ondatachannel 등록 (setRemoteDescription 전!)
    this.pc.ondatachannel = (event) => {
      console.log('[Join] ✅ DataChannel 수신됨!');
      this.dataChannel = event.channel;
      setupDataChannelEvents(this.dataChannel, this.app, 'Join', this.roomId);
    };

    // Offer 적용
    await this.pc.setRemoteDescription(new RTCSessionDescription(offerData));
    console.log('[Join] Offer 적용됨');

    // Answer 생성
    const answer = await this.pc.createAnswer();
    await this.pc.setLocalDescription(answer);
    console.log('[Join] Answer 생성됨');

    await waitForICE(this.pc);

    return { type: 'answer', sdp: this.pc.localDescription.sdp };
  }

  /**
   * P2P 연결 상태 변화 감시
   */
  setupPCEvents() {
    this.pc.oniceconnectionstatechange = () => {
      console.log('[Join ICE]:', this.pc.iceConnectionState);
      if (this.pc.iceConnectionState === 'disconnected' || 
          this.pc.iceConnectionState === 'failed' || 
          this.pc.iceConnectionState === 'closed') {
        console.log('[Join] 연결 종료됨');
        this.app.onConnectionClose?.(this.roomId);
      }
    };
  }

  /**
   * 메시지 전송
   * @param {object} message - 전송할 메시지
   * @returns {boolean} 전송 성공 여부
   */
  send(message) {
    if (this.dataChannel?.readyState === 'open') {
      try {
        this.dataChannel.send(JSON.stringify(message));
        return true;
      } catch (error) {
        console.error('[Join] 메시지 전송 오류:', error);
        return false;
      }
    }
    return false;
  }

  /**
   * 연결 종료
   */
  close() {
    console.log('[Join] 연결 종료');
    this.dataChannel?.close();
    this.pc?.close();
  }
}
