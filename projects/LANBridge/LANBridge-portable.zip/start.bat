@echo off
echo ========================================
echo  LANBridge Portable Launcher
echo ========================================
echo.
echo  NOTE: Always start LANBridge using this file.
echo  Do not run signal-server.js directly.
echo  This script starts the Launcher and Signal Server correctly.
echo.
echo  Starting launcher...
echo.
cd /d "%~dp0"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '169.254*' -and $_.IPAddress -ne '127.0.0.1' } | Select-Object -First 1 -ExpandProperty IPAddress)"`) do set LAN_IP=%%i
if "%LAN_IP%"=="" set LAN_IP=localhost
echo  Open: http://%LAN_IP%:3000
start "LANBridge" "http://%LAN_IP%:3000"
start "LANBridge" "http://localhost:9100"
"C:\Program Files\nodejs\node.exe" launcher.js
pause
